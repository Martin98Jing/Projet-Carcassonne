#include <QPushButton>
#include <QApplication>
#include <QWidget>
#include "header.h"
#include "vueSelectionExtension.h"
#include "vueTuile.h"
#include <QVBoxLayout>
#include "vuePlateau.h"
#include <QScrollArea>
#include "QMainWindow"

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    Controleur c;
    QWidget fenetre;
    QScrollArea scroll;
    VuePLateau test(c.getPlateau());
    QMainWindow m;
    QVBoxLayout vlayout;
    QLabel label;
    fenetre.setLayout(&test);
    scroll.setWidget(&fenetre);
    m.setCentralWidget(&scroll);
    m.show();




    return app.exec();
}


//    QWidget fenetre;
//    QVBoxLayout allo;
//    Site* const tab=new Site [13];
//    for(size_t i=0;i<=12;i++){
//        tab[i]=Site::prairie;
//    }
//    tab[0]=Site::auberge;
//    blocTuile::Tuile* t=new blocTuile::Tuile(tab);


//    std::cout<<t;
//    VueTuile tuile(t);
//    allo.addWidget(&tuile);


//    fenetre.setLayout(&allo);
//    fenetre.show();

//    //vueSelectionExtension *test=new vueSelectionExtension;
//    //test->showMaximized();
//    std::cout<<"\n----------------------------------\n fin du pg";
//    std::cout<<*t;

//    delete[] tab;
//    delete t;
