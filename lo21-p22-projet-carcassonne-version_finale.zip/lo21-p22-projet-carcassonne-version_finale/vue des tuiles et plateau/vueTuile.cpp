#include "vueTuile.h"
#include <QColor>
#include <QPainter>

VueTuile::VueTuile(const blocTuile::Tuile* t, QWidget *parent) : QPushButton(parent),tuile(t)
{
    setBackgroundRole(QPalette::Base);
    setAutoFillBackground(true);
    setFixedSize(150,150);
    connect(this,SIGNAL(clicked()),this,SLOT(clickedEvent()));
    setCheckable(true);
}

VueTuile::VueTuile(QWidget *parent): QPushButton(parent)
{
    setBackgroundRole(QPalette::Base);
    setAutoFillBackground(true);
    setFixedSize(150,150);
    connect(this,SIGNAL(clicked()),this,SLOT(clickedEvent()));
    setCheckable(false);
}

QColor& CouleurCase(Site s,QColor& c){
    switch (s){
    case Site::prairie: {
        c=QColor(20,184,46);
        return c;
        break;

    }//vert fonce
    case Site::jardin: {
        c= QColor(177,244,188);
        return c;
        break;} //vert clair
    case Site::route:
    {
        //std::cout<<"test";
        c= QColor(181,178,178);}
        return c;
        break;
        //gris clair
    case Site::village:
    {
        c= QColor(248,128,61);
        return c;
        break;
    } //gris fonce
    case Site::ville:
    {
        c= QColor(153,91,57);
        return c;
        break;
    } //marron clair
    case Site::cathedrale:
    {
        c= QColor(240,186,156);
        return c;
        break;
    } //bah rien mdr
    case Site::blason:
    {
        c= QColor(120,82,26);
        return c;
        break;
    } //marron fonce
    case Site::source:
    {
        c= QColor(35,188,254);
        return c;
        break;
    } //bleu je suppose
    case Site::lac:
    {
        c= QColor(35,188,254);
        return c;
        break;
    } //pareil
    case Site::riviere:
    {
        c= QColor(35,188,254);
        return c;
        break;
    }//pareil
    case Site::pont:
    {
        c= QColor(153,91,57,100);
        return c;
        break;
    }//bleu fonce
    case Site::abbaye:
    {
        c= QColor(255,193,33);
        return c;
        break;
    }//rouge
    case Site::auberge:
    {
        c= QColor(254,51,6);
        return c;
        break;
    }//orange


    }
}

void VueTuile::paintEvent(QPaintEvent *event){
//    try{
//        std::cout<<"test:"<<*tuile;
//    }
//    catch(CarcasonneException c){
//        std::cout<<c.getInfo()<<"\n";
//    }

    //brush style de coloriage
    QPainter painter(this);




    if(tuile==nullptr){
        QPen pen2(Qt::black);
        painter.setPen(pen2);
        QRect rtest(0,0,150,150);
        painter.drawRect(rtest);

        return;
    }
    QPen pen(Qt::NoPen);
    painter.setPen(pen);
    QColor* c=new QColor(0,0,0);

    QRect r0(50,50,50,50);
    pen.setColor(CouleurCase(tuile->getSite(0),*c));
    painter.drawRect(r0);
    painter.fillRect(r0,pen.brush());

    QPainterPath t1;
    t1.moveTo(0, 0);
    t1.lineTo(0,50);
    t1.lineTo(50,50);
    t1.lineTo(0,0);

    painter.setBrush(CouleurCase(tuile->getSite(1),*c));
    painter.drawPath(t1);

    QPainterPath t2;
    t2.moveTo(0, 0);
    t2.lineTo(50,0);
    t2.lineTo(50,50);
    //CouleurCase(tab[2],*c);
    painter.setBrush(CouleurCase(tuile->getSite(2),*c));
    painter.drawPath(t2);

    QRect r3(50,0,50,50);
    pen.setColor(CouleurCase(tuile->getSite(3),*c));
    painter.drawRect(r3);
    painter.fillRect(r3,pen.brush());

    QPainterPath t4;
    t4.moveTo(100, 0);
    t4.lineTo(150,0);
    t4.lineTo(100,50);
    painter.setBrush(CouleurCase(tuile->getSite(4),*c));

  //  painter.setBrush(CouleurCase(tab[4]));
    painter.drawPath(t4);

    QPainterPath t5;
    t5.moveTo(150, 0);
    t5.lineTo(150,50);
    t5.lineTo(100,50);
    t5.lineTo(150,0);
    painter.setBrush(CouleurCase(tuile->getSite(5),*c));

   // painter.setBrush((CouleurCase(tab[5])));
    painter.drawPath(t5);

    QRect r6(100,50,50,50);
    pen.setColor(CouleurCase(tuile->getSite(6),*c));

  //  pen.setColor((CouleurCase(tab[6])));
    painter.drawRect(r6);
    painter.fillRect(r6,pen.brush());

    QPainterPath t7;
    t7.moveTo(100, 100);
    t7.lineTo(150,100);
    t7.lineTo(150,150);
    t7.lineTo(100,100);
     painter.setBrush(CouleurCase(tuile->getSite(7),*c));
   // painter.setBrush(CouleurCase(tab[7]));
    painter.drawPath(t7);

    QPainterPath t8;
    t8.moveTo(100, 100);
    t8.lineTo(100,150);
    t8.lineTo(150,150);
    t8.lineTo(100,100);
 painter.setBrush(CouleurCase(tuile->getSite(8),*c));
   // painter.setBrush(CouleurCase(tab[8]));
    painter.drawPath(t8);

    QRect r9(50,100,50,50);
    pen.setColor(CouleurCase(tuile->getSite(9),*c));

    //pen.setColor(CouleurCase(tab[9]));
    painter.drawRect(r9);
    painter.fillRect(r9,pen.brush());

    QPainterPath t10;
    t10.moveTo(50, 100);
    t10.lineTo(0,150);
    t10.lineTo(50,150);
     painter.setBrush(CouleurCase(tuile->getSite(10),*c));
   // painter.setBrush(CouleurCase(tab[10]));
    painter.drawPath(t10);

    QPainterPath t11;
    t11.moveTo(50, 100);
    t11.lineTo(0,150);
    t11.lineTo(0,100);
    t11.lineTo(50,100);
     painter.setBrush(CouleurCase(tuile->getSite(11),*c));
   // painter.setBrush(CouleurCase(tab[11]));
    painter.drawPath(t11);

    QRect r12(0,50,50,50);
    pen.setColor(CouleurCase(tuile->getSite(12),*c));

    //pen.setColor(CouleurCase(tab[12]));
    painter.drawRect(r12);
    painter.fillRect(r12,pen.brush());











}

