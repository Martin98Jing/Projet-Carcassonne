#ifndef VUETUILE_H
#define VUETUILE_H
#include <QWidget>
#include <QPen>
#include <QBrush>
#include <QPushButton>
#include <QPainterPath>
#include "header.h"

// affecter une nouvelle carte à la vue
//void setTuile(const ::Carte& c) { setCheckable(true); setChecked(false); carte=&c; update(); }
// vue sans carte




class VueTuile : public QPushButton
{
    Q_OBJECT
public:
    VueTuile(const blocTuile::Tuile* t, QWidget *parent = nullptr);
    explicit VueTuile(QWidget *parent = nullptr);

    const blocTuile::Tuile getTuile() const { return *tuile; }
    bool tuilePresente() const { return tuile!=nullptr; }
    //void setNoTuile() { tuile=nullptr; setCheckable(false); update(); }
protected:
    void paintEvent(QPaintEvent *event) override;
private:
    const blocTuile::Tuile* tuile=nullptr;
    QPen pen;
    QBrush brush;
    signals:
        // quand la vude de carte est cliquée, elle émet un signal en transmettant son adresse
        void carteClicked(VueTuile*);
    public slots:

    private slots:
        void clickedEvent() { emit carteClicked(this);}

};

QColor& CouleurCase(Site s,QColor& c);
#endif // VUETUILE_H
