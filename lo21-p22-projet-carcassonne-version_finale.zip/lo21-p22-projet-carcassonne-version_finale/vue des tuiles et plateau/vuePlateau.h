#ifndef VUEPLATEAU_H
#define VUEPLATEAU_H

#include <QWidget>
#include "vueTuile.h"
#include "header.h"
#include <QGridLayout>

class VuePLateau :public QGridLayout{
    friend class blocComposants::Plateau;
    Q_OBJECT
private:
    blocComposants::Plateau plateau;

public:
    //VueTuile(const blocTuile::Tuile* t, QWidget *parent = nullptr);
    VuePLateau(blocComposants::Plateau p,QWidget *parent=nullptr);

protected:
};

#endif // VUEPLATEAU_H
