#include "vuePlateau.h"

VuePLateau::VuePLateau(blocComposants::Plateau p,QWidget *parent):QGridLayout(parent),plateau(p){
    setHorizontalSpacing(2);
    setVerticalSpacing(2);
    setAlignment(Qt::AlignTop);
    for(size_t i=0;i<X;i++){
        setRowStretch(i,0);
        for(size_t j=0;j<Y;j++){
            VueTuile* vue=new VueTuile(plateau.getTuile(i,j));
            addWidget(vue,i,j);
            setColumnStretch(j,0);
        }
    }
}
