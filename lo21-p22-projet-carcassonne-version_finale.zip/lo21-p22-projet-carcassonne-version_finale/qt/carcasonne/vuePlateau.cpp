#include "vuePlateau.h"
#include "verifMeeple.h"

VuePLateau::VuePLateau(blocComposants::Plateau p,QWidget *parent):QGridLayout(parent),plateau(p){
    setHorizontalSpacing(2);
    setVerticalSpacing(2);
    setAlignment(Qt::AlignTop);
    for(size_t i=0;i<X;i++){
        setRowStretch(i,0);
        for(size_t j=0;j<Y;j++){
            VueTuile* vue=new VueTuile(plateau.getTuile(i,j));
            addWidget(vue,i,j);
            tab_vues[i][j]=vue;
            //setColumnStretch(j,0);
        }
    }
}

//void VuePLateau::retirerTuile(blocTuile::Tuile* t){
//    for(int i=0;i<X;i++){
//        for(int j=0;j<Y;j++){


//        }
//    }

//}

void VuePLateau::ajouterTuilesCompletes(){
    for(int i=0;i<X;i++){
        for(int j=0;j<Y;j++){
            //std::cout<<"\ntest de la tuile"<<i <<"et "<<j<<" " <<recupVue(i,j)->getComplete();
            if(recupVue(i,j)->getComplete()){
                //std::cout<<"\ntuile marque"<<recupVue(i,j)->getTuile();
                verifMeeple* verif=new verifMeeple(nullptr,recupVue(i,j)->getTuile());
                verif->show();
                recupVue(i,j)->retirerComplete();
            }
        }
    }


}

void VuePLateau::rendreCliquable(){
    for(int i=0;i<X;i++){
        for(int j=0;j<Y;j++){
            tab_vues[i][j]->setEnabled(true);
        }
    }
}



void VuePLateau::rendreIncliquable(){
    for(int i=0;i<X;i++){
        for(int j=0;j<Y;j++){
            tab_vues[i][j]->setEnabled(false);
        }
    }
}


void VuePLateau::recupLocVue(VueTuile* t,int* x,int *y) const{
    for(int i=0;i<X;i++){
        for(int j=0;j<Y;j++){
            if(tab_vues[i][j]==t){
                *x=i;
                *y=j;
                return;
            }

        }
    }

}

bool VuePLateau::tuilePresente(VueTuile* t) const{
    for(int i=0;i<X;i++){
        for(int j=0;j<Y;j++){
            if(tab_vues[i][j]==t){
                return 1;
            }

        }
    }
    return 0;

}


//slots

