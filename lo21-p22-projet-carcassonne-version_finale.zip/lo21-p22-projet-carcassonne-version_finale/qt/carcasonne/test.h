#ifndef TEST_H
#define TEST_H
#include <QMainWindow>
#include <QPushButton>
#include <QPainter>
#include <QPainterPath>
#include <QCoreApplication>
//#include <QMouseEvent>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMenuBar>
#include <QLabel>
#include "helpbutton.h"
#include "custombutton.h"
#include "validertourbutton.h"
#include "rotationdroitebutton.h"
#include "rotationgauchebutton.h"
#include "customwidget.h"

#endif // TEST_H
