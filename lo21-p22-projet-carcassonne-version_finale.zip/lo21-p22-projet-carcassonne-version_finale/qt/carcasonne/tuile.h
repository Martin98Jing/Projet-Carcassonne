#ifndef TUILE_H
#define TUILE_H

//#include <QWidget>
//#include <QColor>
//#include "header.h"

//class Tuile : public QWidget
//{
//    Q_OBJECT
//public:
//    explicit Tuile(QWidget *parent = nullptr);

//signals:

//};

//QColor CouleurCase(Site s);

#endif // TUILE_H
