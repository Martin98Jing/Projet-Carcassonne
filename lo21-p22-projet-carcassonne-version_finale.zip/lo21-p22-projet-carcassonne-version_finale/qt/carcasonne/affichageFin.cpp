#include "ajouterFin.h".h"

affichageFin::affichageFin(QWidget *parent):QWidget(parent){
    int nb=Partie::getInstance()->getNbJoueur();
    joueurs=new QLineEdit[nb];
    boxs=new QGroupBox[nb];
    grille=new QGridLayout;
    QVBoxLayout* l_box=new QVBoxLayout[nb];
    QVBoxLayout l_fenetre;

    for(int i=0;i<nb;i++){
        std::string nom="Nombre de points de: "+Partie::getInstance()->getJoueur(i)->getNom();
        boxs[i].setTitle(QString::fromStdString(nom));
        joueurs[i].setText("0");
        l_box[i].addWidget(&joueurs[i]);
        boxs[i].setLayout(&l_box[i]);
        grille->addWidget(&boxs[i],i,0);

    }
    valider_b=new QPushButton("valider");
    connect(valider_b,SIGNAL(clicked()),this,SLOT(valider()));

    grille->addWidget(valider_b,nb,0);
    setLayout(grille);
    setWindowTitle("Saisie des points finale");

}
void affichageFin::valider(){
    int nb=Partie::getInstance()->getNbJoueur();
    QString recup[nb];
    bool test[6]={1,1,1,1,1,1};
    int points[nb];
    for(int i=0;i<nb;i++){
        recup[i]=joueurs[i].text();
        points[i]=recup[i].toInt(&test[i],10);
        std::cout<<"\n"<<test[i];
    }
    if(test[0]==0 ||test[1]==0 ||test[2]==0 ||test[3]==0 ||test[4]==0 ||test[5]==0){
        QMessageBox message_warning(QMessageBox::Icon::Warning,
                                    "Attention...",
                                    "Au moins l'une des saisies n'est pas valide");

      message_warning.exec();

    }
    else{
        vainqueur=new QLabel("Grille des points");
        grille_fin=new QGridLayout;
        grille->addWidget(vainqueur,0,0);
        score=new QLabel[Partie::getInstance()->getNbJoueur()];


        for(int i=0;i<nb;i++){
           // Partie::getInstance()->getJoueur(i)->setPoitns(points[i]);
           // int points=Partie::getInstance()->getJoueur(i)->getPoints();
//            std::string str="Points de "+Partie::getInstance()->getJoueur(i)->getNom()+" "+std::to_string(points);
            //score[i].setText(QString::fromStdString(str));
            //grille_fin->addWidget(&score[i],i+1,0);
            grille->removeWidget(&boxs[i]);
            boxs[i].close();
           }

        for(int i=0;i<nb;i++){
            Partie::getInstance()->getJoueur(i)->setPoitns(points[i]);
            int points=Partie::getInstance()->getJoueur(i)->getPoints();
            std::string str="Points de "+Partie::getInstance()->getJoueur(i)->getNom()+" "+std::to_string(points);
            score[i].setText(QString::fromStdString(str));
            grille->addWidget(&score[i],i+1,0);
            //grille->removeWidget(&boxs[i]);
            //boxs[i].close();
           }
        //grille->removeWidget(valider_b);
        valider_b->close();
        setLayout(grille);
        grille->setAlignment(Qt::AlignCenter);
        update();
    }


}
