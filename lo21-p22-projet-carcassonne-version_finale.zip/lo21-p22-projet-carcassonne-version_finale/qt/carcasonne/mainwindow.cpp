#include "mainwindow.h"
#include <QDebug>
#include "regleMeeple.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle("Carcassone");
    c =new Controleur;

    m_mainWidget = new QWidget(this);
    m_hLayoutMain = new QHBoxLayout(this);
    m_vLayoutRight = new QVBoxLayout(this);
    m_vLayoutLeft = new QVBoxLayout(this);
    m_hLayout = new QHBoxLayout(this);
   // m_meeplesLayout = new QHBoxLayout(this);
    m_hLayoutMap = new QHBoxLayout(this);
    //m_score = new QLabel("Scores: ", this);
    m_rotDroite = new RotationDroiteButton(this);
    m_rotGauche = new RotationGaucheButton(this);
    //m_carteHolder = new QPushButton("Carte Holder", this);
    blocTuile::Tuile* t=nullptr;
    m_carteHolder=new VueTuile(t);
    m_nomJoueur = new QLabel("Nom du Joueur", this);
    m_couleurJoueur = new QLabel("Couleur du Joueur", this);
    m_meeples = new QLabel("Meeples restants", this);
    //m_poseMeeples = new QMenuBar(this);
    m_validerTourButton = new QPushButton("Valider tour");
    //m_helpButton = new HelpButton(this);

    //boutons
    valider_tuile=new QPushButton("Valider tuile");
    poser_meeple=new QPushButton("action meeple");
    element_complete=new QPushButton("Element complete");
    reprendre_tuile=new QPushButton("Reprendre tuile");
    valider_selection=new QPushButton("Valider elements");
    fin_partie=new QPushButton("Fin partie");

    //gestion score
    tab_scores=new QLabel[Partie::getInstance()->getNbJoueur()];


    zone_scores=new QGroupBox;
    l_scores=new QVBoxLayout;
    zone_scores->setTitle("Scores");

    //gestion du plateau
    lplateau=new QVBoxLayout;
    plateau=new QLabel("plateau");
    m_plateau=new QWidget;
    m_vueplateau=new VuePLateau(c->getPlateau());
    scroll=new QScrollArea;





    setCentralWidget(m_mainWidget);



    // Layout horizontal gauche
    //m_hLayout->addWidget(m_score);
    m_hLayout->addSpacing(50);
    m_hLayout->addWidget(m_rotGauche);
    m_hLayout->addWidget(m_carteHolder);
    m_hLayout->addWidget(m_rotDroite);
    m_hLayout->addSpacing(50);

    lplateau->addWidget(plateau);
    lplateau->addLayout(m_vueplateau);//ajout de la grille
    m_plateau->setLayout(lplateau);
    scroll->setWidget(m_plateau);

    // Layout vertical gauche
    m_vLayoutLeft->addLayout(m_hLayout);
    m_vLayoutLeft->addWidget(scroll);

    // Layout Meeples + règles relatives
    //m_meeplesLayout->addWidget(m_meeples, 80);
    //m_meeplesLayout->addWidget(m_helpButton, 20);

    //tableau des scores




    //infos joueurs

    zone_infos=new QGroupBox;
    l_infos=new QVBoxLayout;
    zone_infos->setTitle("Zone informations ");
    l_infos->addWidget(m_nomJoueur);
    l_infos->addWidget(m_couleurJoueur);
    l_infos->addWidget(m_meeples);
    zone_infos->setLayout(l_infos);
    //    m_vLayoutRight->addWidget(m_nomJoueur);
    //    m_vLayoutRight->addWidget(m_couleurJoueur);
    //    m_vLayoutRight->addLayout(m_meeplesLayout);
    //m_vLayoutRight->addWidget(m_poseMeeples);

    //tableau des scores
    for(int i=0;i<Partie::getInstance()->getNbJoueur();i++){
        int points=Partie::getInstance()->getJoueur(i)->getPoints();
        std::string str="Points de "+Partie::getInstance()->getJoueur(i)->getNom()+" "+std::to_string(points);
        tab_scores[i].setText(QString::fromStdString(str));
        l_scores->addWidget(&tab_scores[i]);
        //        m_vLayoutRight->addWidget(&tab_scores[i]);

    }
    zone_scores->setLayout(l_scores);

    // Layout vertical de droite
    //QSpacerItem* spacer = new QSpacerItem(30,500);
   // m_vLayoutRight->addSpacerItem(spacer);
    m_vLayoutRight->addWidget(zone_infos);
    m_vLayoutRight->addWidget(zone_scores);
    // QSpacerItem* spacer = new QSpacerItem(30,500);
   // m_vLayoutRight->addSpacerItem(spacer);

    m_vLayoutRight->addWidget(reprendre_tuile,10);
    m_vLayoutRight->addWidget(valider_tuile, 10);
    m_vLayoutRight->addWidget(poser_meeple, 10);
    m_vLayoutRight->addWidget(element_complete, 10);
    m_vLayoutRight->addWidget(valider_selection, 10);
    m_vLayoutRight->addWidget(m_validerTourButton, 10);
    m_vLayoutRight->addWidget(fin_partie, 10);

    m_vLayoutRight->setAlignment(Qt::AlignCenter);

    // Layout horizontal principal
    m_hLayoutMain->addLayout(m_vLayoutLeft, 90);
    m_hLayoutMain->addLayout(m_vLayoutRight, 10);
    m_mainWidget->setLayout(m_hLayoutMain);


    //initialisation des boutons
    connect(m_rotDroite,SIGNAL(clicked()),this,SLOT(rotationDroite()));
    connect(m_rotGauche,SIGNAL(clicked()),this,SLOT(rotationGauche()));
    connect(reprendre_tuile,SIGNAL(clicked()),this,SLOT(reprendreTuile()));
    connect(valider_tuile,SIGNAL(clicked()),this,SLOT(validerTuile()));
    connect(poser_meeple,SIGNAL(clicked()),this,SLOT(reglesMeeple()));
    connect(m_validerTourButton,SIGNAL(clicked()),this,SLOT(finTour()));
    connect(valider_selection,SIGNAL(clicked()),this,SLOT(validerSelection()));
    connect(element_complete,SIGNAL(clicked()),this,SLOT(activerSelection()));
    connect(fin_partie,SIGNAL(clicked()),this,SLOT(finPartie()));


    //fonctions de test
    jouerPartie();


}
void MainWindow::jouerPartie(){
    c->creerPioche();
    viderPiocheEnJeu();


}
void MainWindow::viderPiocheEnJeu(){
    QMessageBox message_warning(QMessageBox::Icon::Warning,
                                "Attention...",
                                "Il n'y a plus de tuile");
    if(!c->getPioche()->estVide())
        piocherTuile();
    else
        message_warning.exec();

}

void MainWindow::piocherTuile(){     //activer les boutons de rotations

    //maj du joueur en cours
    std::string nom="Nom du joueur: " +Partie::getInstance()->getJoueurEnCours()->getNom();
    m_nomJoueur->setText(QString::fromStdString(nom));

    std::string couleur="Couleur du joueur: "+toString(Partie::getInstance()->getJoueurEnCours()->getCouleur());
    m_couleurJoueur->setText(QString::fromStdString(couleur));
    std::string meeples="Meeples restants: "+std::to_string(Partie::getInstance()->getJoueurEnCours()->MeepleRestants());
    m_meeples->setText(QString::fromStdString(meeples));

    //maj tableau des scores

    for(int i=0;i<Partie::getInstance()->getNbJoueur();i++){
        int points=Partie::getInstance()->getJoueur(i)->getPoints();
        std::string str="Points de "+Partie::getInstance()->getJoueur(i)->getNom()+" "+std::to_string(points);
        tab_scores[i].setText(QString::fromStdString(str));
        ////        m_vLayoutRight->addWidget(&tab_scores[i]);
    }


    //pioche une tuile dans la pioche et la met dans le carte holder
    c->piocherTuile();
    std::cout<<"\ntest de la pioche "<<Partie::getInstance()->getTuileEnJeu();
    m_carteHolder->setTuile(*Partie::getInstance()->getTuileEnJeu());
    m_rotGauche->setEnabled(true);
    m_rotDroite->setEnabled(true);
    reprendre_tuile->setEnabled(false);
    valider_tuile->setEnabled(false);
    poser_meeple->setEnabled(false);
    valider_selection->setEnabled(false);
    element_complete->setEnabled(false);
    m_vueplateau->rendreCliquable();

    for(int i=0;i<X;i++){
        for(int j=0;j<Y;j++){
            connect(m_vueplateau->recupVue(i,j),&VueTuile::carteClicked,this,&MainWindow::placerTuile);

        }
    }
}
void MainWindow::reprendreTuile(){
    int *x=new int;
    int *y=new int;
    c->retirerTuilePlateau(Partie::getInstance()->getTuileEnJeu(),x,y);
    //std::cout<<c->getPlateau();
    m_vueplateau->retirerVue(*x,*y);
    m_vueplateau->rendreCliquable();
    m_rotGauche->setEnabled(true);
    m_rotDroite->setEnabled(true);
    reprendre_tuile->setEnabled(false);
    valider_tuile->setEnabled(false);




}

void MainWindow::placerTuile(){
    QMessageBox message_warning(QMessageBox::Icon::Warning,
                                "Attention...",
                                "Emplacement voulu non valide");
    int *x=new int;
    int *y=new int;
    VueTuile* tuile_appuyee=qobject_cast<VueTuile*>(sender());
    std::cout<<c->getPlateau();

    if(tuile_appuyee){
        bool placement_valide=0;
        m_vueplateau->recupLocVue(tuile_appuyee,x,y);
        //std::cout<<"\n indice recup "<<*x<<" "<<*y;
        try{

            placement_valide=c->ajouterTuilePlateau(*x,*y);
        }
        catch(CarcasonneException c){
            std::cout<<"\n"<<c.getInfo();
        }

        if(placement_valide){
            tuile_appuyee->setTuile(*Partie::getInstance()->getTuileEnJeu()); //on redessine la tuile
            m_vueplateau->rendreIncliquable();//on desac les boutons pour pas modif l'état du jeu
            m_rotGauche->setEnabled(false);
            m_rotDroite->setEnabled(false);
            reprendre_tuile->setEnabled(true);
            valider_tuile->setEnabled(true);
            m_validerTourButton->setEnabled(false);
        }
        else{
            message_warning.exec();
        }

    }


    delete x;
    delete y;
}

void MainWindow::validerTuile(){
    valider_tuile->setEnabled(false);
    reprendre_tuile->setEnabled(false);
    poser_meeple->setEnabled(true);
    element_complete->setEnabled(true);
    m_validerTourButton->setEnabled(true);
    for(int i=0;i<X;i++){
        for(int j=0;j<Y;j++){
            disconnect(m_vueplateau->recupVue(i,j),&VueTuile::carteClicked,this,&MainWindow::placerTuile);

        }
    }




}

void MainWindow::reglesMeeple(){
    poser_meeple->setEnabled(false);
    regleMeeple* meeple=new regleMeeple(c);
    meeple->show();

}

void MainWindow::activerSelection(){
    m_vueplateau->rendreCliquable();
    for(int i=0;i<X;i++){
        for(int j=0;j<Y;j++){
            connect(m_vueplateau->recupVue(i,j),&VueTuile::carteClicked,this,&MainWindow::ajouterTuileCompletion);
        }
    }

    valider_selection->setEnabled(true);
}
void MainWindow::validerSelection(){
    element_complete->setEnabled(false);
    valider_selection->setEnabled(false);
    m_vueplateau->rendreIncliquable();
    for(int i=0;i<X;i++){
        for(int j=0;j<Y;j++){
            disconnect(m_vueplateau->recupVue(i,j),&VueTuile::carteClicked,this,&MainWindow::ajouterTuileCompletion);

        }
    }
    m_vueplateau->ajouterTuilesCompletes();


    //    RegleElementComplete regle;
    //    c->setRegle(&regle);
    //    try{
    //        c->execute();
    //    }
    //    catch(CarcasonneException c){
    //        std::cout<<c.getInfo();
    //    }
//    RegleElementComplete regle;
//    c->setRegle(&regle);
//    try{
//        c->execute();
//    }
//    catch(CarcasonneException c){
//        std::cout<<c.getInfo();
//    }
    m_carteHolder->update();
    SaisiePoints* saisie=new SaisiePoints(nullptr,c);
    saisie->show();
    //fenetre saisie points


}


void MainWindow::ajouterTuileCompletion(){
    QMessageBox message_warning(QMessageBox::Icon::Warning,
                                "Attention...",
                                "Emplacement voulu non valide");
    VueTuile* tuile_appuyee=qobject_cast<VueTuile*>(sender());
    if(tuile_appuyee){
        if(!tuile_appuyee->getComplete()){
            tuile_appuyee->validerComplete();
            //message_warning.exec();
        }
        else
            tuile_appuyee->retirerComplete();

        tuile_appuyee->update();
    }
}

void MainWindow::finTour(){
    QMessageBox message_warning(QMessageBox::Icon::Warning,
                                "Attention...",
                                "fin du tour");
    // message_warning.exec();

    c->finDeTour();
    viderPiocheEnJeu();
    /* if(!c->getPioche()->estVide())
        piocherTuile()*/;
}

void MainWindow::finPartie(){
    //desactive les boutons
    m_rotGauche->setEnabled(false);
    m_rotDroite->setEnabled(false);
    reprendre_tuile->setEnabled(false);
    valider_tuile->setEnabled(false);
    poser_meeple->setEnabled(false);
    valider_selection->setEnabled(false);
    element_complete->setEnabled(false);
    m_validerTourButton->setEnabled(false);
    fin_partie->setEnabled(false);

    m_vueplateau->rendreIncliquable();
    affichageFin* fin=new affichageFin;
    fin->show();
}


MainWindow::~MainWindow()
{
    qDebug() << "Bye" << Qt::endl;
}

