#include "SaisiePoints.h"

SaisiePoints::SaisiePoints(QWidget *parent,Controleur* ctrl):QWidget(parent),c(ctrl){
    int nb=Partie::getInstance()->getNbJoueur();
    joueurs=new QLineEdit[nb];
    boxs=new QGroupBox[nb];
    grille=new QGridLayout;
    QVBoxLayout* l_box=new QVBoxLayout[nb];
    QVBoxLayout l_fenetre;

    for(int i=0;i<nb;i++){
        std::string nom="Nombre de points de: "+Partie::getInstance()->getJoueur(i)->getNom();
        boxs[i].setTitle(QString::fromStdString(nom));
        joueurs[i].setText("0");
        l_box[i].addWidget(&joueurs[i]);
        boxs[i].setLayout(&l_box[i]);
        grille->addWidget(&boxs[i],i,0);

    }
    valider_b=new QPushButton("valider");
    connect(valider_b,SIGNAL(clicked()),this,SLOT(valider()));

    grille->addWidget(valider_b,nb,0);
    setLayout(grille);
    setWindowTitle("Saisie des points");

}
void SaisiePoints::valider(){
    RegleElementComplete regle;
    c->setRegle(&regle);
    try{
        c->execute();
    }
    catch(CarcasonneException c){
        std::cout<<c.getInfo();
    }
    int nb=Partie::getInstance()->getNbJoueur();
    QString recup[nb];
    bool test[6]={1,1,1,1,1,1};
    int points[nb];
    for(int i=0;i<nb;i++){
        recup[i]=joueurs[i].text();
        points[i]=recup[i].toInt(&test[i],10);
        std::cout<<"\n"<<test[i];
    }
    if(test[0]==0 ||test[1]==0 ||test[2]==0 ||test[3]==0 ||test[4]==0 ||test[5]==0){
        QMessageBox message_warning(QMessageBox::Icon::Warning,
                                    "Attention...",
                                    "Au moins l'une des saisies n'est pas valide");

        message_warning.exec();

    }
    else{
        for(int i=0;i<nb;i++){
            Partie::getInstance()->getJoueur(i)->setPoitns(points[i]);
        }
        this->close();
    }


}
