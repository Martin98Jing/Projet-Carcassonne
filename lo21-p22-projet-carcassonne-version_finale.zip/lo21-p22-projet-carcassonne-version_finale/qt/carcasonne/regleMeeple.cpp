#include "regleMeeple.h"

regleMeeple::regleMeeple(Controleur* c,QWidget *parent):QWidget(parent),c(c){


  tab=new QRadioButton [3]  ;
  valider= new QPushButton("valider");
  infos=new QLabel("Choissiez l'action que vous voulez effetuer:");
  saisie=new QLineEdit;
  l_boutons=new QHBoxLayout;
  l_fenetre=new QVBoxLayout;
  connect(valider,SIGNAL(clicked()),this,SLOT(valider1()));
  tab[0].setText("poser meeple");
  tab[0].setChecked(true);
  tab[1].setText("reprendre abbaye");
  tab[2].setText("déplacer meeple");

  for(size_t i=0;i<3;i++){
      l_boutons->addWidget(&tab[i]);
  }

  l_fenetre->addWidget(infos);
  l_fenetre->addLayout(l_boutons);
  l_fenetre->addWidget(valider);
  l_fenetre->setAlignment(Qt::AlignCenter);
  setLayout(l_fenetre);


}

void regleMeeple::affichage2(){
    infos->setText("Choisissez l'indice ou placer votre "
                   "meeple (consulter doc pour la correspondance) :");
    l_fenetre->removeItem(l_boutons);
    l_fenetre->removeWidget(valider);

    l_fenetre->addWidget(saisie);
    l_fenetre->addWidget(valider);
    connect(valider,SIGNAL(clicked()),this,SLOT(valider2()));



}

void regleMeeple::valider1(){
    QMessageBox message_warning(QMessageBox::Icon::Warning,
                                    "Attention...",
                                    "Regle pas implementé,regle par défaut lancé soit poser meeple");


    std::cout<<"test";
    if(tab[1].isChecked()||tab[2].isChecked())
        message_warning.exec();
    affichage2();
}

void regleMeeple::valider2(){
    QMessageBox message_warning(QMessageBox::Icon::Warning,
                                    "Attention...",
                                    "Votre saisie n'est pas valide");
    QString recup=saisie->text();
    bool test=0;
    int pos=recup.toInt(&test,10);
    if(test){
        if(pos<0 ||pos >12){
            message_warning.exec();

        }
        else{
            //on ajoute notre meeple
            c->setPosMeeple(pos);
            std::cout<<"\n pos meeple tuile:" <<pos;
            ReglePoserMeeple posermeeple;
            c->setRegle(&posermeeple);
            try{
                c->execute();
               // std::cout<<"\ntest de la position du meeple:"<<*Partie::getInstance()->getTuileEnJeu();
                c->setRegle(nullptr);
                this->close();
            }
            catch(CarcasonneException c){
                QMessageBox message_warning(QMessageBox::Icon::Warning,
                                                "Attention...",
                                                "Vous ne pouvez pas poser de meeple à la position souhaitée");
                message_warning.exec();
                std::cout<<c.getInfo();

            }

        }

    }
    else{
        message_warning.exec();
    }



}

