#ifndef ROTATIONDROITEBUTTON_H
#define ROTATIONDROITEBUTTON_H

#include <QPushButton>
#include <QObject>
#include <QWidget>
#include <iostream>

class RotationDroiteButton : public QPushButton
{
    Q_OBJECT
public:
    RotationDroiteButton(QWidget* parent);
    //void mousePressEvent(QMouseEvent* event);

};

#endif // ROTATIONDROITEBUTTON_H
