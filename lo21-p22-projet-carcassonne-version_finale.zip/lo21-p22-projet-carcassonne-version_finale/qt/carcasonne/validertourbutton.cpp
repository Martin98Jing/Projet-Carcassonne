#include "validertourbutton.h"


ValiderTourButton::ValiderTourButton(QWidget *parent) : QPushButton(parent)
{
    setText("Valider le tour");
}

void ValiderTourButton::mousePressEvent(QMouseEvent *event)
{
//    if (event->button() == Qt::LeftButton) {
//        QCoreApplication::quit();
//    }
}
