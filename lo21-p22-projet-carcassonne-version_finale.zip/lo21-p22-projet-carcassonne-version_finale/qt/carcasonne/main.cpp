#include <QPushButton>
#include <QApplication>
#include <QWidget>
#include "header.h"
#include "vueSelectionExtension.h"
#include "vueTuile.h"
#include <QVBoxLayout>
#include "vuePlateau.h"
#include <QScrollArea>
#include "QMainWindow"

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);

        vueSelectionExtension* select_ext=new vueSelectionExtension;
        select_ext->showMaximized();
//    Site contenu[13];
//    for (size_t i=0; i < 13; i++)
//        contenu[i] = Site::route;
//    blocTuile::Tuile* t=new blocTuile::Tuile(contenu);
//    VueTuile* vue=new VueTuile(t);
//    vue->validerComplete();
//    vue->show();



    return app.exec();
}
//test dessin meeple


//       blocJoueur::Joueur j("pierre",Couleur::rouge);
//       blocTuile::Extensions e("test");
//       Partie::getInstance()->ajouterExtension(&e);
//       Partie::getInstance()->ajouterJoueur(&j);
//       Controleur c;
//       c.creerPioche();
//       c.piocherTuile();
//       VueTuile vue(Partie::getInstance()->getTuileEnJeu());
//       vue.show();
//       c.setPosMeeple(2);
//       std::cout<<"allo"<<c.getPosMeeple();
//       ReglePoserMeeple test;
//       c.setRegle(&test);
//       try{
//           c.execute();
//       }
//       catch(CarcasonneException c){
//std::cout<<c.getInfo();
//      }

//        Controleur c;
//        QWidget fen;
//        QVBoxLayout lh;
//        QLabel l("test");
//        QWidget fenetre;
//        QScrollArea scroll;
//        VuePLateau test(c.getPlateau());
//        QMainWindow m;
//        QVBoxLayout vlayout;
//        QLabel label("test");
//        QLabel th("test horizontal");
//        //fenetre.setLayout(&test);

//        lh.addWidget(&l);


//        vlayout.addWidget(&label);
//        vlayout.addLayout(&test);
//        fenetre.setLayout(&vlayout);

//        //lh.addWidget(&fenetre);
//        scroll.setWidget(&fenetre);
//        lh.addWidget(&scroll);
//        fen.setLayout(&lh);
//        m.setCentralWidget(&fen);
//        m.show();






//    Controleur c;
//    QWidget fenetre;
//    QScrollArea scroll;
//    VuePLateau test(c.getPlateau());
//    QMainWindow m;
//    QVBoxLayout vlayout;
//    QLabel label;
//    fenetre.setLayout(&test);
//    scroll.setWidget(&fenetre);
//    m.setCentralWidget(&scroll);
//    m.show();

//    QWidget fenetre;
//    QVBoxLayout allo;
//    Site* const tab=new Site [13];
//    for(size_t i=0;i<=12;i++){
//        tab[i]=Site::prairie;
//    }
//    tab[0]=Site::auberge;
//    blocTuile::Tuile* t=new blocTuile::Tuile(tab);


//    std::cout<<t;
//    VueTuile tuile(t);
//    allo.addWidget(&tuile);


//    fenetre.setLayout(&allo);
//    fenetre.show();

//    //vueSelectionExtension *test=new vueSelectionExtension;
//    //test->showMaximized();
//    std::cout<<"\n----------------------------------\n fin du pg";
//    std::cout<<*t;

//    delete[] tab;
//    delete t;
