#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QPainter>
#include <QPainterPath>
#include <QCoreApplication>
//#include <QMouseEvent>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMenuBar>
#include <QLabel>
#include "helpbutton.h"
#include "custombutton.h"
#include "validertourbutton.h"
#include "rotationdroitebutton.h"
#include "rotationgauchebutton.h"
#include "customwidget.h"
#include "vuePlateau.h"
#include "vueTuile.h"
#include "header.h"
#include <QScrollArea>
#include <QMessageBox>
#include "SaisiePoints.h"
#include "ajouterFin.h"


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void piocherTuile();
    void jouerPartie();
    void viderPiocheEnJeu();
    Controleur* getControleur(){return c;}

private:
    Controleur* c;
    QPushButton* m_validerTourButton;
    RotationDroiteButton* m_rotDroite;
    RotationGaucheButton* m_rotGauche;
    //QPushButton* m_carteHolder;
    VueTuile* m_carteHolder;

    QLabel* m_score;
    //infos joueurs
    QGroupBox* zone_infos;
    QVBoxLayout* l_infos;
    QLabel* m_nomJoueur;
    QLabel* m_couleurJoueur;
    QLabel* m_meeples;


    QMenuBar* m_poseMeeples;
    QWidget* m_mainWidget;

    QWidget* m_plateau;
    VuePLateau* m_vueplateau;
    QScrollArea* scroll;

    //HelpButton* m_helpButton;

    QHBoxLayout* m_hLayoutMain; //séparation gauche droite
    QVBoxLayout* m_vLayoutRight; //infos joueur
    QVBoxLayout* m_vLayoutLeft; //séparation map infos
    QHBoxLayout* m_hLayout; //infos partie (en haut)
    QHBoxLayout* m_hLayoutMap; //map
   // QHBoxLayout* m_meeplesLayout; //meeples rules

    QVBoxLayout* lplateau;
    QLabel* plateau;
    //zone des scores
    QLabel* tab_scores;
    QGroupBox* zone_scores;
    QVBoxLayout* l_scores;

    //QPushButton* m_testButton;
    QPushButton* valider_tuile;
    QPushButton* poser_meeple;
    QPushButton* element_complete;
    QPushButton* reprendre_tuile;
    QPushButton* valider_selection;
    QPushButton* fin_partie;



public slots:
    void rotationDroite(){
        //std::cout<<"\non fait tourner la tuile sur la droite";
        Partie::getInstance()->getTuileEnJeu()->rotationDroite();
        m_carteHolder->update();
    }
    void rotationGauche(){
        //std::cout<<"\non fait tourner la tuile sur la Gauche";
        Partie::getInstance()->getTuileEnJeu()->rotationGauche();
        m_carteHolder->update();
    }
    void placerTuile();
    void reprendreTuile();
    void validerTuile();
    void reglesMeeple();
    void activerSelection();
    void validerSelection();
    void ajouterTuileCompletion();
    void finTour();
    void finPartie();


};
#endif // MAINWINDOW_H
