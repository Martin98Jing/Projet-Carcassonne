#include "tuile.h"


//Tuile::Tuile(QWidget *parent)
//    : QWidget{parent}
//{

//QColor CouleurCase(Site s){
//    switch (s){
//        case Site::prairie: return QColor(20,184,46);;
//        case Site::jardin: return QColor(177,244,188);
//        case Site::"route" : return QColor(181,178,178);
//        case Site:: "village" : return QColor(248,128,61);
//        case s == "ville" : return QColor(153,91,57);
//        case s == "cathedrale" : return QColor(240,186,156);
//        case s == "blason" : return QColor(120,82,26);
//        case s == "source" : return QColor(35,188,254);
//        case s == "lac" : return QColor(35,188,254);
//        case s == "riviere" : return QColor(35,188,254);
//        case s == "pont" : return QColor(153,91,57,100);
//        case s == "abbaye" : return QColor(255,193,33);
//        case s == "auberge" : return QColor(254,51,6);
//    }
//}

////Foction affichage
//void AffichageTuile()
//{
//    QPainter painter(this);
//    QPen pen(Qt::black);
//    painter.setPen(pen);

//    QPainterPath t1;
//    t1.moveTo(10, 10);
//    t1.lineTo(10,110);
//    t1.lineTo(110,110);
//    painter.setBrush(CouleurCase(T.Site[1]));
//    painter.drawPath(t1);

//    QPainterPath t2;
//    t2.moveTo(10, 10);
//    t2.lineTo(110,10);
//    t2.lineTo(110,110);
//    painter.setBrush(CouleurCase(T.Site[2]));
//    painter.drawPath(t2);

//    QRect r3(110,10,100,100);
//    pen.setColor(CouleurCase(T.Site[3]));
//    painter.drawRect(r3);
//    painter.fillRect(r3,pen.brush());

//    QPainterPath t4;
//    t4.moveTo(210, 10);
//    t4.lineTo(310,10);
//    t4.lineTo(210,110);
//    painter.setBrush(CouleurCase(T.Site[4]));
//    painter.drawPath(t4);

//    QPainterPath t5;
//    t5.moveTo(210, 110);
//    t5.lineTo(310,10);
//    t5.lineTo(310,110);
//    painter.setBrush((CouleurCase(T.Site[5]));
//    painter.drawPath(t5);

//    QRect r6(210,110,100,100);
//    pen.setColor((CouleurCase(T.Site[6]));
//    painter.drawRect(r6);
//    painter.fillRect(r6,pen.brush());

//    QPainterPath t7;
//    t7.moveTo(210, 210);
//    t7.lineTo(310,210);
//    t7.lineTo(310,310);
//    painter.setBrush(CouleurCase(T.Site[7]));
//    painter.drawPath(t7);

//    QPainterPath t8;
//    t8.moveTo(210, 210);
//    t8.lineTo(210,310);
//    t8.lineTo(310,310);
//    painter.setBrush(CouleurCase(T.Site[8]));
//    painter.drawPath(t8);

//    QRect r9(110,210,100,100);
//    pen.setColor(CouleurCase(T.Site[9]));
//    painter.drawRect(r9);
//    painter.fillRect(r9,pen.brush());

//    QPainterPath t10;
//    t10.moveTo(110, 210);
//    t10.lineTo(10,310);
//    t10.lineTo(110,310);
//    painter.setBrush(CouleurCase(T.Site[10]));
//    painter.drawPath(t10);

//    QPainterPath t11;
//    t11.moveTo(110, 210);
//    t11.lineTo(10,310);
//    t11.lineTo(10,210);
//    painter.setBrush(CouleurCase(T.Site[11]));
//    painter.drawPath(t11);

//    QRect r12(10,110,100,100);
//    pen.setColor(CouleurCase(T.Site[12]));
//    painter.drawRect(r12);
//    painter.fillRect(r12,pen.brush());

//    QRect r0(110,110,100,100);
//    pen.setColor(CouleurCase(T.Site[0]));
//    painter.drawRect(r0);
//    painter.fillRect(r0,pen.brush());
//}
//}
