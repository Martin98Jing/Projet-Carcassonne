#include "vueSelectionExtension.h"

vueSelectionExtension::vueSelectionExtension(QWidget *parent):QWidget(parent){

    setWindowTitle("Choix de l'extension");
    //création des widgets
    texte= new QLabel("Choissisez l'extension majeure avec laquelle vous voulez jouer:");
    valider= new QPushButton("valider",this);
    vlayout= new QVBoxLayout;
    extensions= new QGroupBox(tr("Choix des extensions"));
    grid= new QGridLayout;
    disposition_boutons=new QVBoxLayout;

    //creation des boutons des extensions
    e1=new QRadioButton(tr("Auberge et cathédrale"));
    e2=new QRadioButton(tr("test"));
    e1->setChecked(true);

   //disposition des boutons
    disposition_boutons->addWidget(e1);
    disposition_boutons->addWidget(e2);

   //connecte le bouton au slot
    connect(valider,SIGNAL(clicked()),this,SLOT(BoutonClique()));


    //construction fenêtre
    vlayout->addWidget(texte);
    vlayout->addSpacing(50);
    vlayout->addLayout(disposition_boutons);
    vlayout->addWidget(valider);
    vlayout->setAlignment(Qt::AlignCenter);
    setLayout(vlayout);
}

void vueSelectionExtension::BoutonClique(){
    //blocTuile::Extensions* ex1=new blocTuile::Extensions("Abbe");
    //blocTuile::Extensions* ex2=new blocTuile::Extensions("Paysan");
    //blocTuile::Extensions* ex3=new blocTuile::Extensions("Base");
    blocTuile::Extensions* ex4=new blocTuile::Extensions("Base");
    blocTuile::Extensions* maj=nullptr;

    if(e1->isChecked())
        maj=new blocTuile::Extensions("Auberges_et_Cathedrales");

        //maj=new blocTuile::Extensions("Auberges_et_Cathedrales");

     //Partie::getInstance()->ajouterExtension(ex1);
     //Partie::getInstance()->ajouterExtension(ex2);
    // Partie::getInstance()->ajouterExtension(ex3);
     Partie::getInstance()->ajouterExtension(ex4);
     Partie::getInstance()->ajouterExtension(maj);
     //Partie::getInstance()->afficherTuiles();


     CreationJoueur* fenetre=new CreationJoueur;
     fenetre->showMaximized();
     delete this;
}
