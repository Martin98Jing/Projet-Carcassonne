#ifndef VUETUILE_H
#define VUETUILE_H
#include <QWidget>
#include <QPen>
#include <QBrush>
#include <QPushButton>
#include <QPainterPath>
#include "header.h"

// affecter une nouvelle carte à la vue
// vue sans carte




class VueTuile : public QPushButton
{
    Q_OBJECT
public:
    VueTuile(blocTuile::Tuile* t, QWidget *parent = nullptr);
    explicit VueTuile(QWidget *parent = nullptr);

    blocTuile::Tuile* getTuile() const { return tuile; }
    bool tuilePresente() const { return tuile!=nullptr; }
    void setNoTuile() {
        tuile=nullptr;
        setChecked(false);
        setCheckable(true);
         }
    void setTuile(blocTuile::Tuile&  t) {
        setCheckable(true);
        setChecked(false);
        std::cout<<"\nmaj de la tuile";
        tuile=&t;

        update(); }

    void setClr(QColor* clr){
        couleur_j_meeple=clr;
    }
    void setMeeplePose(){
        meeple_pose=1;
    }

protected:
    void paintEvent(QPaintEvent *event) override;
public:
    void validerComplete()
    {
        if(tuile){
            std::cout<<"\nvue selectione"<<*tuile;
          complete=1;
          update();
        }
    }

    void retirerComplete()
    {
        if(tuile){
          complete=0;
          update();
        }
    }
    bool getComplete(){return complete;}
private:
    blocTuile::Tuile* tuile=nullptr;
    QPen pen;
    QBrush brush;
    bool complete;
    QColor* couleur_j_meeple;
    bool meeple_pose;
    signals:
        // quand la vude de carte est cliquée, elle émet un signal en transmettant son adresse
        void carteClicked(VueTuile*);
    public slots:

    private slots:
        void clickedEvent() { emit carteClicked(this);}

};

QColor& CouleurCase(Site s,QColor& c);
QColor& CouleurJoueur(Couleur clr,QColor& c);
#endif // VUETUILE_H
