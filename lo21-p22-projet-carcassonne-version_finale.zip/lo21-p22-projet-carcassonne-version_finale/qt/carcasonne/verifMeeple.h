#ifndef VERIFMEEPLE_H
#define VERIFMEEPLE_H


#include <QMessageBox>
#include <QLabel>
#include <QVBoxLayout>
#include <QPushButton>
#include <QRadioButton>
#include <QGridLayout>
#include <QGroupBox>
#include <QLineEdit>
#include <QWidget>
#include "header.h"
#include "vueTuile.h"



class verifMeeple : public QWidget
 {
     Q_OBJECT

 public:
     verifMeeple(QWidget *parent=nullptr,blocTuile::Tuile* t=nullptr);

 private:
     //QLineEdit Joueur[nb_Joueur];
    bool resultat;
    QRadioButton* oui;
    QRadioButton* non;
    QLabel* label;
    QVBoxLayout* layout;
    QPushButton* valider_b;
    VueTuile* vue_testee;



public slots:
     void valider();
 };
#endif // VERIFMEEPLE_H
