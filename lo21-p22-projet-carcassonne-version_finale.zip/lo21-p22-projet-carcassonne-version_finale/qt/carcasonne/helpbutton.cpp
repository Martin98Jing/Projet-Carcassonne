#include "helpbutton.h"


HelpButton::HelpButton(QWidget *parent) : QPushButton(parent)
{
    setText("?");
}

void HelpButton::mousePressEvent(QMouseEvent *event)
{
//    if (event->button() == Qt::LeftButton) {
//        QMessageBox::information(this, "Règles du jeu", "Afficher les règles du jeu");
//    }
}
