#ifndef VUESELECTIONEXTENSION_H
#define VUESELECTIONEXTENSION_H

#include <QLabel>
#include <QVBoxLayout>
#include <QPushButton>
#include <QRadioButton>
#include <QGridLayout>
#include <QGroupBox>

#include <QWidget>
#include "header.h"
#include "CreationJoueur.h"

class QPushButton;
class QLabel;
class QVBoxLayout;
class QRadioButton;



class vueSelectionExtension: public QWidget{
Q_OBJECT
public:
    explicit vueSelectionExtension(QWidget *parent=nullptr);
private:
    QLabel* texte;
    QVBoxLayout* vlayout;
    QPushButton* valider;
    QGroupBox* extensions;
    QVBoxLayout* disposition_boutons;
    QRadioButton* e1;
    QRadioButton* e2;

    QGridLayout* grid;
public slots:
    void BoutonClique();

};

#endif // VUESELECTIONEXTENSION_H
