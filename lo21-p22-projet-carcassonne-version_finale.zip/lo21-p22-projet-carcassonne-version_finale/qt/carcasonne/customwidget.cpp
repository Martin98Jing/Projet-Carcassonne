#include "customwidget.h"
#include <QPainter>

CustomWidget::CustomWidget(QWidget *parent)
    : QWidget{parent}
{

}

void CustomWidget::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setPen(Qt::black);
    painter.setBrush(Qt::blue);
    painter.drawRoundedRect(0, 0, this->width(), this->height(), 20, 20);
    painter.setPen(Qt::white);
    painter.drawText(this->width()*0.5f - 30, this->height() * 0.5f, "Scores :");
    updateGeometry();
}
