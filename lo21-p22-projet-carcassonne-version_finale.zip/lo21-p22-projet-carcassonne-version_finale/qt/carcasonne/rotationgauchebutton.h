#ifndef ROTATIONGAUCHEBUTTON_H
#define ROTATIONGAUCHEBUTTON_H

#include <QPushButton>
#include <QObject>
#include <QWidget>

class RotationGaucheButton : public QPushButton
{
    Q_OBJECT
public:
    RotationGaucheButton(QWidget* parent);
    //void mousePressEvent(QMouseEvent* event);
};

#endif // ROTATIONGAUCHEBUTTON_H
