#ifndef SAISIEPOINTS_H
#define SAISIEPOINTS_H

#include <QMessageBox>
#include <QLabel>
#include <QVBoxLayout>
#include <QPushButton>
#include <QRadioButton>
#include <QGridLayout>
#include <QGroupBox>
#include <QLineEdit>
#include <QWidget>
#include "header.h"



class SaisiePoints : public QWidget
 {
     Q_OBJECT

 public:
     SaisiePoints(QWidget *parent=nullptr,Controleur* ctrl=nullptr);

 private:
     //QLineEdit Joueur[nb_Joueur];
     QLineEdit *joueurs;
     QGridLayout* grille;
     QGroupBox *boxs;
     QPushButton *valider_b;
     Controleur* c;

public slots:
     void valider();
 };

#endif // SAISIEPOINTS_H
