#ifndef REGLEMEEPLE_H
#define REGLEMEEPLE_H
#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QPushButton>
#include <QRadioButton>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include "header.h"
#include <QMessageBox>
#include <QLineEdit>
#include <QString>


class regleMeeple:public QWidget{
    Q_OBJECT
private:
    Controleur* c;
    QRadioButton* tab;
    QPushButton* valider;
    QLabel* infos;
    QLineEdit* saisie;
    QHBoxLayout* l_boutons;
    QVBoxLayout* l_fenetre;
    void affichage1();
    void affichage2();

public:
     regleMeeple(Controleur* c,QWidget *parent=nullptr);


public slots:
     void valider1();
     void valider2();

};

#endif // REGLEMEEPLE_H
