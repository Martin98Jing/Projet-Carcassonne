#ifndef VUEPLATEAU_H
#define VUEPLATEAU_H

#include <QWidget>
#include "vueTuile.h"
#include "header.h"
#include <QGridLayout>
#include <QMessageBox>
class VuePLateau :public QGridLayout{
    friend class blocComposants::Plateau;
    Q_OBJECT
private:
    blocComposants::Plateau plateau;
    VueTuile* tab_vues[X][Y];

public:
    //VueTuile(const blocTuile::Tuile* t, QWidget *parent = nullptr);
    VuePLateau(blocComposants::Plateau p,QWidget *parent=nullptr);
    VueTuile* recupVue(int x, int y) {return tab_vues[x][y];}

    void recupLocVue(VueTuile* t,int* x,int *y) const;
    bool tuilePresente(VueTuile* t) const;
    void retirerVue(int x,int y){tab_vues[x][y]->setNoTuile();}
    void rendreIncliquable();
    void rendreCliquable();
    void ajouterTuilesCompletes();



protected:

};

#endif // VUEPLATEAU_H
