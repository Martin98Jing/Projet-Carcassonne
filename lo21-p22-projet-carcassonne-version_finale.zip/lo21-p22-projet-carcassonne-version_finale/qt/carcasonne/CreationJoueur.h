#ifndef CREATIONJOUEUR_H
#define CREATIONJOUEUR_H
#include <QLabel>
#include <QVBoxLayout>
#include <QPushButton>
#include <QRadioButton>
#include <QGridLayout>
#include <QGroupBox>
#include <QLineEdit>

#include <QWidget>
#include "header.h"


class CreationJoueur:public QWidget{
    Q_OBJECT
public:
    explicit CreationJoueur(QWidget *parent=nullptr);
    Couleur recupererCouleur();
    void majBoutons();
private:
    int nb;
    QLabel* texte;
    QPushButton* valider;
    QPushButton* ajouter_joueur;
    QGroupBox* boutons;
    QRadioButton* c1;
    QRadioButton* c2;
    QRadioButton* c3;
    QRadioButton* c4;
    QRadioButton* c5;
    QRadioButton* c6;

    QRadioButton* ia;
    QRadioButton* humain;
    QHBoxLayout* type_joueur;

    QVBoxLayout* placement_boutons;
    QVBoxLayout* disposition;
    QLineEdit* nom_joueur;
    QHBoxLayout* layout_nom;
    QHBoxLayout* test;

    QLabel* label_nom;
public slots:
    void BoutonValider();
    void BoutonAjouterJoueurs();
};

#endif // CREATIONJOUEUR_H
