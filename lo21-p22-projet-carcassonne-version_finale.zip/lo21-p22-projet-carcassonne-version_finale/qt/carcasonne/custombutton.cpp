#include "custombutton.h"
#include <QDebug>


CustomButton::CustomButton(QWidget *parent, QString texte) : QPushButton(parent)
{
    setText(texte);
}

CustomButton::~CustomButton()
{
    qDebug() << "Destruction" << Qt::endl;
}
