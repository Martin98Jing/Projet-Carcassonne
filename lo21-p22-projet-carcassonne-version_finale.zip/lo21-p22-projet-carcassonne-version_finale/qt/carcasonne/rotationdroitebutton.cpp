#include "rotationdroitebutton.h"


RotationDroiteButton::RotationDroiteButton(QWidget *parent) : QPushButton(parent)
{
    setText("Rotation à droite");
}

