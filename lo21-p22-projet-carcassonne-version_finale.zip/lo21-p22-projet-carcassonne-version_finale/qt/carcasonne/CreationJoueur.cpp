#include "CreationJoueur.h"
#include <QMessageBox>
#include "mainwindow.h"

CreationJoueur::CreationJoueur(QWidget *parent):QWidget(parent),nb(1){

//    int nb;
//    QPushButton* valider;
//    QPushButton* ajouter_joueur;
//    QGroupBox* boutons;
//    QRadioButton* c1;
//    QRadioButton* c2;
//    QRadioButton* c3;
//    QRadioButton* c4;
//    QRadioButton* c5;
//    QRadioButton* c6;
//    QVBoxLayout* placement_boutons;
//    QVBoxLayout* disposition;

    //création des éléments
    texte=new QLabel("Menu ajouter les joueurs:");
    valider=new QPushButton("Commencer la partie");
    ajouter_joueur=new QPushButton("Ajouter le joueur");
    nom_joueur=new QLineEdit("test");
    label_nom=new QLabel("Saisissez le nom du joueur :");
    layout_nom=new QHBoxLayout;
    test=new QHBoxLayout;
    boutons=new QGroupBox;

    //boutons radio pour la couleur
    c1=new QRadioButton(tr("rouge"));
    c2=new QRadioButton(tr("bleu"));
    c3=new QRadioButton(tr("vert"));
    c4=new QRadioButton(tr("jaune"));
    c5=new QRadioButton(tr("noir"));
    c6=new QRadioButton(tr("gris"));
    c1->setChecked(true);

    placement_boutons=new QVBoxLayout;
    disposition=new QVBoxLayout;
    //boutons radio pour le type de joueur
    ia=new QRadioButton("IA");
    humain=new QRadioButton("Humain");
    humain->setChecked(true);
    type_joueur=new QHBoxLayout;

    type_joueur->addWidget(ia);
    type_joueur->addWidget(humain);
    type_joueur->setAlignment(Qt::AlignCenter);

    //mise en place label
    layout_nom->addWidget(label_nom);
    layout_nom->addWidget(nom_joueur);


    //creation fenetre
    placement_boutons->addWidget(c1);
    placement_boutons->addWidget(c2);
    placement_boutons->addWidget(c3);
    placement_boutons->addWidget(c4);
    placement_boutons->addWidget(c5);
    placement_boutons->addWidget(c6);
    boutons->setLayout(placement_boutons);
    placement_boutons->setAlignment(Qt::AlignCenter);

    test->addWidget(texte);
    test->setAlignment(Qt::AlignCenter);
    disposition->addLayout(test);
    //disposition->addWidget(texte);
    //disposition->addWidget(nom_joueur);
    disposition->addLayout(layout_nom);
    disposition->addLayout(type_joueur);
    disposition->addWidget(boutons);
    disposition->addWidget(ajouter_joueur);
    disposition->addWidget(valider);


    disposition->setAlignment(Qt::AlignCenter);

    setLayout(disposition);

    connect(valider,SIGNAL(clicked()),this,SLOT(BoutonValider()));
    connect(ajouter_joueur,SIGNAL(clicked()),this,SLOT(BoutonAjouterJoueurs()));

}
Couleur CreationJoueur::recupererCouleur(){
    if(c1->isChecked()){
        c1->hide();
        return Couleur::rouge;
    }
    if(c2->isChecked()){
        c2->hide();
        return Couleur::bleu;
    }
    if(c3->isChecked()){
        c3->hide();
        return Couleur::vert;
    }
    if(c4->isChecked()){
        c4->hide();
        return Couleur::jaune;
    }
    if(c5->isChecked()){
        c5->hide();
        return Couleur::noir;
    }
    if(c6->isChecked()){
        c6->hide();
        return Couleur::gris;
    }

}

void CreationJoueur::majBoutons(){
    if(!c1->isHidden()){
        c1->setChecked(true);
        return;
    }
    if(!c2->isHidden()){
        c2->setChecked(true);
        return;
    }
    if(!c3->isHidden()){
        c3->setChecked(true);
        return;
    }
    if(!c4->isHidden()){
        c4->setChecked(true);
        return;
    }
    if(!c5->isHidden()){
        c5->setChecked(true);
        return;
    }
    if(!c6->isHidden()){
        c6->setChecked(true);
        return;
    }

}
void CreationJoueur::BoutonAjouterJoueurs(){
    QString nom=nom_joueur->text();
    if(humain->isChecked()){
        Couleur clr=recupererCouleur();

        blocJoueur::Joueur* j=new blocJoueur::Joueur(nom.toStdString(),clr);
        Partie::getInstance()->ajouterJoueur(j);
        Partie::getInstance()->afficherJoueurs();
        nb++;
        majBoutons();
        update();
    }
    else{
        QMessageBox message_warning(QMessageBox::Icon::Warning,
                                                "Attention...",
                                                "Vous ne pouvez pas encore créer d'IA..., c'est un joueur humain qui a été rajouté");
        message_warning.exec();

    }


}
void CreationJoueur::BoutonValider(){
    if(nb<3){
        QMessageBox message_warning(QMessageBox::Icon::Warning,
                                                "Attention...",
                                                "Vous n'avez pas encore ajouter assez de joueurs");
        message_warning.exec();

    }
    else{
        //lancer la partie
        MainWindow* fenetre=new MainWindow;
        fenetre->showMaximized();
        delete this;
    }
}
