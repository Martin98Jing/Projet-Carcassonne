#include "verifMeeple.h"

verifMeeple::verifMeeple(QWidget *parent,blocTuile::Tuile* t):QWidget(parent){
    vue_testee=new VueTuile(t);

    QColor* clr=new QColor;
    if(t->getMeeple()){
        blocJoueur::Joueur* j=t->getMeeple()->Proprietaire_ptr();
        if(j){
            CouleurJoueur(j->getCouleur(),*clr);
            vue_testee->setClr(clr);
            vue_testee->setMeeplePose();
        }
    }
    label=new QLabel("Le Meeple doit-il être retiré ?");
    oui=new QRadioButton("oui");
    non=new QRadioButton("non");
    layout=new QVBoxLayout;
    valider_b=new QPushButton("valider");
    non->setChecked(true);
    connect(valider_b,SIGNAL(clicked()),this,SLOT(valider()));

    layout->addWidget(label);
    layout->addWidget(vue_testee);
    layout->addWidget(oui);
    layout->addWidget(non);
    layout->addWidget(valider_b);
    layout->setAlignment(Qt::AlignCenter);
    setLayout(layout);


}


//bool resultat;
//QRadioButton* oui;
//QRadioButton* non;
//QLabel* label;
//QVBoxLayout* layout;
//QPushButton* valider_b;
//VueTuile* vue_testee;

void verifMeeple::valider(){
    if(oui->isChecked()){
        Partie::getInstance()->ajouterTuileComplete(vue_testee->getTuile());
    }
    this->close();

}
