#ifndef HELPBUTTON_H
#define HELPBUTTON_H

#include <QPushButton>
#include <QObject>
#include <QWidget>
//#include <QMouseEvent>
#include <QMessageBox>

class HelpButton : public QPushButton
{
    Q_OBJECT

public:
    HelpButton(QWidget* parent);
    void mousePressEvent(QMouseEvent* event);

};

#endif // HELPBUTTON_H
