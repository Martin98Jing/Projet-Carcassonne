#ifndef AJOUTERFIN_H
#define AJOUTERFIN_H
#include <QMessageBox>
#include <QLabel>
#include <QVBoxLayout>
#include <QPushButton>
#include <QRadioButton>
#include <QGridLayout>
#include <QGroupBox>
#include <QLineEdit>
#include <QWidget>
#include "header.h"

class affichageFin : public QWidget
 {
     Q_OBJECT

 public:
     explicit affichageFin(QWidget *parent=nullptr);

 private:
     //QLineEdit Joueur[nb_Joueur];
     QLineEdit *joueurs;
     QGridLayout* grille;
     QGroupBox *boxs;
     QPushButton *valider_b;
     QLabel* vainqueur;
     QLabel* score;
     QGridLayout* grille_fin;



public slots:
     void valider();
 };

#endif // AJOUTERFIN_H
