#ifndef VALIDERTOURBUTTON_H
#define VALIDERTOURBUTTON_H

#include <QPushButton>
#include <QObject>
#include <QWidget>
//#include <QMouseEvent>
#include <QCoreApplication>

class ValiderTourButton : public QPushButton
{
    Q_OBJECT
public:
    ValiderTourButton(QWidget* parent);
    void mousePressEvent(QMouseEvent* event);

};

#endif // VALIDERTOURBUTTON_H
