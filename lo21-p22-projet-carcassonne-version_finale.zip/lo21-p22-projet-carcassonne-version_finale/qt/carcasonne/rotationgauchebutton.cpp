#include "rotationgauchebutton.h"

RotationGaucheButton::RotationGaucheButton(QWidget *parent) : QPushButton(parent) {
    setText("Rotation à gauche");
}


